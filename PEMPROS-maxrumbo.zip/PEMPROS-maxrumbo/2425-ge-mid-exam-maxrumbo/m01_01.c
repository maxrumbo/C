// 12S24037 - Maxwell Rumahorbo
// 12S24020 - Joice Napitupulu

#include <stdio.h>
#include <string.h>

typedef struct {
    char nama[100];
    int bobot;
    int nilai;
} KomponenPenilaian;

int main(int argc, char *argv[]) {
    if (argc != 2 || (int)*argv[1] < '1' || (int)*argv[1] > '5') {
        printf("Error\n");
        return 1;
    }

    int k = (int)*argv[1] - '0';
    KomponenPenilaian komponen[k];

    for (int i = 0; i < k; i++) {
        scanf("%[^#]#%d#%d", komponen[i].nama, &komponen[i].bobot, &komponen[i].nilai);
        getchar(); 
    }

    for (int i = 0; i < k; i++) {
        printf("%s;%d;%d\n", komponen[i].nama, komponen[i].bobot, komponen[i].nilai);
    }

    float nilaiAkhir = 0;
    int totalBobot = 0;
    for (int i = 0; i < k; i++) {
        nilaiAkhir += (float)komponen[i].nilai * komponen[i].bobot;
        totalBobot += komponen[i].bobot;
    }

    nilaiAkhir = (float)nilaiAkhir / totalBobot;

    printf("%.1f\n", nilaiAkhir);

    if (nilaiAkhir >= 60.0) {
        printf("passed\n");
    } else {
        printf("failed\n");
    }

    return 0;
}
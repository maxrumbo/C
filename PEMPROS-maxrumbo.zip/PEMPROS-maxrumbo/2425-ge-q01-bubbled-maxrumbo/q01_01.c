// 12S24037 - Maxwell Rumahorbo
// 12S24020 - Joice Anastasya Napitupulu

#include <stdio.h>

#define MAX_LENGTH 100

int main() {
    char input[MAX_LENGTH + 1];
    char karakter[MAX_LENGTH];
    int count = 0;

    fgets(input, MAX_LENGTH + 1, stdin);

    int i = 0;
    while (input[i] != '\0') {
        if (input[i] == ',') {
            i++;
        } else {
            karakter[count++] = input[i];
            i++;
        }
    }

    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (karakter[i] > karakter[j]) {
                char temp = karakter[i];
                karakter[i] = karakter[j];
                karakter[j] = temp;
            }
        }
    }

    printf("%c", karakter[0]);
    for (int i = 1; i < count; i++) {
        printf(",%c", karakter[i]);
    }

    return 0;
}
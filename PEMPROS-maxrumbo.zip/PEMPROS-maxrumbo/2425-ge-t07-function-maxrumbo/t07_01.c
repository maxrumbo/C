// DO NOT EDIT
#include "academic.h"
#include <stdio.h>

int main(int _argc, char **_argv)
{
    // implement academic.create_student(...)
    struct student_t std_wiro =
        create_student("12S22999", "Wiro Sableng", "2022", "Information Systems");

    // implement academic.print_student(...)
    print_student(std_wiro);

    return 0;
}
// DO NOT EDIT
